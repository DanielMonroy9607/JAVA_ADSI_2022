/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FUNCIONARIO;


/**
 *
 * @author Daniel
 */
public class funcionariosBL {
    
    int id_funcionario;
    String nombre_funcionario, apellido_funcionario,cc_funcionario, area_funcionario,correo_funcionario;

    public int getId_funcionario() {
        return id_funcionario;
    }

    public void setId_funcionario(int id_funcionario) {
        this.id_funcionario = id_funcionario;
    }

    public String getCc_funcionario() {
        return cc_funcionario;
    }

    public void setCc_funcionario(String cc_funcionario) {
        this.cc_funcionario = cc_funcionario;
    }

    public String getNombre_funcionario() {
        return nombre_funcionario;
    }

    public void setNombre_funcionario(String nombre_funcionario) {
        this.nombre_funcionario = nombre_funcionario;
    }

    public String getApellido_funcionario() {
        return apellido_funcionario;
    }

    public void setApellido_funcionario(String apellido_funcionario) {
        this.apellido_funcionario = apellido_funcionario;
    }

    public String getArea_funcionario() {
        return area_funcionario;
    }

    public void setArea_funcionario(String carrera_funcionario) {
        this.area_funcionario = carrera_funcionario;
    }

    public String getCorreo_funcionario() {
        return correo_funcionario;
    }

    public void setCorreo_funcionario(String correo_funcionario) {
        this.correo_funcionario = correo_funcionario;
    }
    
    
}
