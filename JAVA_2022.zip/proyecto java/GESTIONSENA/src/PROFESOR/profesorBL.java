/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PROFESOR;
/**
 *
 * @author Daniel
 */
public class profesorBL {
    
    int id_profesor;
    String nombre_profesor, apellido_profesor,cc_profesor, carrera_profesor,correo_profesor;

    public int getId_profesor() {
        return id_profesor;
    }

    public void setId_profesor(int id_profesor) {
        this.id_profesor = id_profesor;
    }

    public String getCc_profesor() {
        return cc_profesor;
    }

    public void setCc_profesor(String cc_profesor) {
        this.cc_profesor = cc_profesor;
    }

    public String getNombre_profesor() {
        return nombre_profesor;
    }

    public void setNombre_profesor(String nombre_profesor) {
        this.nombre_profesor = nombre_profesor;
    }

    public String getApellido_profesor() {
        return apellido_profesor;
    }

    public void setApellido_profesor(String apellido_profesor) {
        this.apellido_profesor = apellido_profesor;
    }

    public String getCarrera_profesor() {
        return carrera_profesor;
    }

    public void setCarrera_profesor(String carrera_profesor) {
        this.carrera_profesor = carrera_profesor;
    }

    public String getCorreo_profesor() {
        return correo_profesor;
    }

    public void setCorreo_profesor(String correo_profesor) {
        this.correo_profesor = correo_profesor;
    }
    
    
}
