
package DB;

import java.sql.*;

public class Conexion {
    
    String strConexionDB="jdbc:sqlite:C:/Project_ADSI/sqliteadmin/DB_GESTIONSENA.s3db";
    Connection conn=null;
    
    public Conexion(){
        
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection(strConexionDB);
            
            System.out.println("Conexion Establecida");
        } catch (Exception e) {
            
            System.out.println("Conexion Errada" + e);
        }
    }
    
    public int ejecutarSentenciaSQL(String strSentenciaSQL){
        
        try {
            PreparedStatement pstm =conn.prepareStatement(strSentenciaSQL);
            pstm.execute();
            return 1;
        } catch (SQLException e) {
            System.out.println(e);
            return 0;
        }
    }
    
    
    public ResultSet consultarRegistros(String strSentenciaSQL){
        try {
            PreparedStatement pstm =conn.prepareStatement(strSentenciaSQL);
            ResultSet respuesta =pstm.executeQuery();
            return respuesta;
            
        } catch (Exception e) {
            System.out.println(e);
            return null;

        }
    }
    
       public void eliminarSentenciaSQL(String strSentenciaSQL){
        
        try {
            PreparedStatement pstm =conn.prepareStatement(strSentenciaSQL);
            pstm.execute();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

       public void editarSentenciaSQL(String strSentenciaSQL){
        
        try {
            PreparedStatement pstm =conn.prepareStatement(strSentenciaSQL);
            pstm.execute();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
}